REST API for any Postgres database
