-- This file is required by Hackage.
import Distribution.Simple
main = defaultMain
